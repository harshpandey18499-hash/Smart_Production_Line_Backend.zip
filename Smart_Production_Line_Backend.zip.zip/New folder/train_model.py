"""
Train a Random Forest downtime classifier on synthetic production-line data.

Outputs:
  model.pkl   – RandomForestClassifier
  scaler.pkl  – StandardScaler fitted on feature columns
"""

from __future__ import annotations

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

RANDOM_SEED = 42
N_SAMPLES = 8000
FEATURE_COLS = ["vibration", "temperature", "wear", "rpm", "load"]
LABEL_NAMES = {0: "NORMAL", 1: "WARNING", 2: "CRITICAL"}


def synthesize_training_data(n: int, rng: np.random.Generator) -> pd.DataFrame:
    """Physics-inspired telemetry with labeled downtime risk."""
    # Wear is the slow driver of most failures (0–100 %).
    wear = rng.beta(2.0, 3.2, n) * 100.0

    load = np.clip(rng.normal(62.0, 16.0, n), 15.0, 100.0)
    rpm = np.clip(rng.normal(1480.0, 180.0, n) + load * 1.4, 700.0, 2200.0)

    vibration = (
        0.8
        + wear * 0.055
        + (load / 100.0) * 1.6
        + rng.normal(0.0, 0.35, n)
    )
    # Occasional bearing-fault spikes
    spike_mask = rng.random(n) < 0.06
    vibration[spike_mask] += rng.uniform(3.5, 7.5, spike_mask.sum())
    vibration = np.clip(vibration, 0.3, 18.0)

    temperature = (
        36.0
        + wear * 0.28
        + (load / 100.0) * 18.0
        + (rpm / 2000.0) * 8.0
        + rng.normal(0.0, 1.8, n)
    )
    overheat = rng.random(n) < 0.05
    temperature[overheat] += rng.uniform(12.0, 28.0, overheat.sum())
    temperature = np.clip(temperature, 28.0, 125.0)

    # Label rules: 0 NORMAL, 1 WARNING, 2 CRITICAL (imminent downtime)
    label = np.zeros(n, dtype=int)
    warning = (
        (wear >= 55)
        | (vibration >= 5.5)
        | (temperature >= 72)
        | ((load >= 85) & (wear >= 40))
    )
    critical = (
        (wear >= 82)
        | (vibration >= 8.5)
        | (temperature >= 92)
        | ((wear >= 70) & (vibration >= 6.8))
        | ((temperature >= 80) & (wear >= 65))
    )
    label[warning] = 1
    label[critical] = 2

    return pd.DataFrame(
        {
            "vibration": vibration,
            "temperature": temperature,
            "wear": wear,
            "rpm": rpm,
            "load": load,
            "label": label,
        }
    )


def main() -> None:
    rng = np.random.default_rng(RANDOM_SEED)
    df = synthesize_training_data(N_SAMPLES, rng)

    print("Class balance:")
    print(df["label"].map(LABEL_NAMES).value_counts().to_string())
    print()

    x = df[FEATURE_COLS].values
    y = df["label"].values

    x_train, x_test, y_train, y_test = train_test_split(
        x, y, test_size=0.2, random_state=RANDOM_SEED, stratify=y
    )

    scaler = StandardScaler()
    x_train_s = scaler.fit_transform(x_train)
    x_test_s = scaler.transform(x_test)

    clf = RandomForestClassifier(
        n_estimators=220,
        max_depth=14,
        min_samples_leaf=3,
        class_weight="balanced",
        random_state=RANDOM_SEED,
        n_jobs=-1,
    )
    clf.fit(x_train_s, y_train)

    y_pred = clf.predict(x_test_s)
    print("Classification report:")
    print(classification_report(y_test, y_pred, target_names=["NORMAL", "WARNING", "CRITICAL"]))
    print("Confusion matrix:")
    print(confusion_matrix(y_test, y_pred))
    print()
    print("Feature importances:")
    for name, imp in sorted(zip(FEATURE_COLS, clf.feature_importances_), key=lambda t: -t[1]):
        print(f"  {name:12s} {imp:.3f}")

    joblib.dump(clf, "model.pkl")
    joblib.dump(scaler, "scaler.pkl")
    print("\nSaved model.pkl and scaler.pkl")


if __name__ == "__main__":
    main()
