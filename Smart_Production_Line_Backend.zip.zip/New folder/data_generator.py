"""
Publish realistic production-line telemetry to HiveMQ Cloud public broker.

Topic JSON payload:
  machine_id, ts, vibration, temperature, wear, rpm, load
"""

from __future__ import annotations

import json
import random
import signal
import sys
import time
import uuid
from datetime import datetime, timezone

import paho.mqtt.client as mqtt

BROKER_HOST = "broker.hivemq.com"
BROKER_PORT = 1883
MQTT_TOPIC = "smart-factory/downtime-pred/v1/telemetry"
PUBLISH_INTERVAL_SEC = 1.0

MACHINES = [
    {"id": "CNC-01", "role": "CNC mill", "base_rpm": 1620, "wear_rate": 0.042},
    {"id": "PRESS-02", "role": "Hydraulic press", "base_rpm": 980, "wear_rate": 0.055},
    {"id": "CONV-03", "role": "Conveyor", "base_rpm": 720, "wear_rate": 0.028},
    {"id": "WELD-04", "role": "Robotic welder", "base_rpm": 1180, "wear_rate": 0.036},
]


class MachineSim:
    def __init__(self, spec: dict) -> None:
        self.id = spec["id"]
        self.role = spec["role"]
        self.base_rpm = spec["base_rpm"]
        self.wear_rate = spec["wear_rate"]
        self.wear = random.uniform(8.0, 28.0)
        self.load = random.uniform(40.0, 70.0)
        self.temp = 42.0
        self.vib = 1.6
        self.degrading = random.random() < 0.35
        self.fault_timer = 0

    def step(self) -> dict:
        # Slow wear climb; some units degrade faster this session
        drift = self.wear_rate * (1.8 if self.degrading else 1.0)
        self.wear = min(99.5, self.wear + drift + random.uniform(-0.01, 0.02))

        # Load cycles like a real line (shift-style)
        self.load += random.uniform(-4.5, 4.8)
        self.load = float(max(18.0, min(98.0, self.load)))

        rpm = self.base_rpm + (self.load - 50.0) * 4.2 + random.uniform(-35, 35)
        rpm = float(max(500.0, min(2300.0, rpm)))

        target_temp = (
            36.0
            + self.wear * 0.27
            + (self.load / 100.0) * 17.0
            + (rpm / 2000.0) * 7.0
        )
        self.temp += (target_temp - self.temp) * 0.25 + random.uniform(-0.6, 0.6)

        target_vib = 0.9 + self.wear * 0.052 + (self.load / 100.0) * 1.5
        self.vib += (target_vib - self.vib) * 0.3 + random.uniform(-0.12, 0.12)

        # Transient faults: imbalance / dry bearing / thermal runaway
        if self.fault_timer <= 0 and random.random() < 0.04:
            self.fault_timer = random.randint(3, 8)
        if self.fault_timer > 0:
            kind = random.choice(["vib", "temp", "both"])
            if kind in ("vib", "both"):
                self.vib += random.uniform(1.8, 4.2)
            if kind in ("temp", "both"):
                self.temp += random.uniform(4.0, 11.0)
            self.fault_timer -= 1

        self.vib = float(max(0.4, min(16.0, self.vib)))
        self.temp = float(max(28.0, min(118.0, self.temp)))

        return {
            "machine_id": self.id,
            "role": self.role,
            "ts": datetime.now(timezone.utc).isoformat(),
            "vibration": round(self.vib, 3),
            "temperature": round(self.temp, 2),
            "wear": round(self.wear, 2),
            "rpm": round(rpm, 1),
            "load": round(self.load, 2),
        }


def build_client() -> mqtt.Client:
    client_id = f"spl-gen-{uuid.uuid4().hex[:10]}"
    client = mqtt.Client(
        mqtt.CallbackAPIVersion.VERSION2,
        client_id=client_id,
        protocol=mqtt.MQTTv311,
    )

    def on_connect(c, _u, _f, reason_code, _p):
        print(f"[MQTT] connected rc={reason_code} id={client_id}")

    def on_disconnect(c, _u, _d, reason_code, _p):
        print(f"[MQTT] disconnected rc={reason_code}")

    client.on_connect = on_connect
    client.on_disconnect = on_disconnect
    client.reconnect_delay_set(min_delay=1, max_delay=15)
    return client


def main() -> None:
    running = True

    def handle_stop(_sig, _frame):
        nonlocal running
        running = False

    signal.signal(signal.SIGINT, handle_stop)
    if hasattr(signal, "SIGTERM"):
        signal.signal(signal.SIGTERM, handle_stop)

    sims = [MachineSim(spec) for spec in MACHINES]
    client = build_client()
    print(f"Publishing to {BROKER_HOST}:{BROKER_PORT} topic={MQTT_TOPIC}")
    client.connect(BROKER_HOST, BROKER_PORT, keepalive=60)
    client.loop_start()

    try:
        while running:
            payload = random.choice(sims).step()
            body = json.dumps(payload)
            info = client.publish(MQTT_TOPIC, body, qos=0)
            if info.rc != mqtt.MQTT_ERR_SUCCESS:
                print(f"[MQTT] publish failed rc={info.rc}")
            else:
                print(
                    f"{payload['machine_id']:9s}  vib={payload['vibration']:5.2f}  "
                    f"temp={payload['temperature']:6.1f}C  wear={payload['wear']:5.1f}%  "
                    f"load={payload['load']:5.1f}%"
                )
            time.sleep(PUBLISH_INTERVAL_SEC)
    finally:
        client.loop_stop()
        client.disconnect()
        print("Generator stopped.")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)
