"""
FastAPI hub: HiveMQ subscriber -> SQLite -> Random Forest inference -> WebSocket UI.
"""

from __future__ import annotations

import asyncio
import json
import sqlite3
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import paho.mqtt.client as mqtt
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "telemetry.db"
MODEL_PATH = BASE_DIR / "model.pkl"
SCALER_PATH = BASE_DIR / "scaler.pkl"
STATIC_DIR = BASE_DIR / "static"

BROKER_HOST = "broker.hivemq.com"
BROKER_PORT = 1883
MQTT_TOPIC = "smart-factory/downtime-pred/v1/telemetry"
FEATURE_COLS = ["vibration", "temperature", "wear", "rpm", "load"]
STATUS_MAP = {0: "NORMAL", 1: "WARNING", 2: "CRITICAL"}

MACHINE_META = {
    "CNC-01": {"role": "CNC mill", "station": "CUT"},
    "PRESS-02": {"role": "Hydraulic press", "station": "FORM"},
    "CONV-03": {"role": "Conveyor", "station": "MOVE"},
    "WELD-04": {"role": "Robotic welder", "station": "JOIN"},
}

model = None
scaler = None
mqtt_client: mqtt.Client | None = None
event_loop: asyncio.AbstractEventLoop | None = None


class Hub:
    def __init__(self) -> None:
        self.clients: set[WebSocket] = set()
        self.latest: dict[str, dict[str, Any]] = {}
        self.lock = asyncio.Lock()

    async def connect(self, ws: WebSocket) -> None:
        await ws.accept()
        async with self.lock:
            self.clients.add(ws)

    async def disconnect(self, ws: WebSocket) -> None:
        async with self.lock:
            self.clients.discard(ws)

    async def broadcast(self, message: dict[str, Any]) -> None:
        payload = json.dumps(message)
        async with self.lock:
            dead: list[WebSocket] = []
            for ws in self.clients:
                try:
                    await ws.send_text(payload)
                except Exception:
                    dead.append(ws)
            for ws in dead:
                self.clients.discard(ws)


hub = Hub()


def db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    conn = db()
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS telemetry (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts TEXT NOT NULL,
            machine_id TEXT NOT NULL,
            vibration REAL,
            temperature REAL,
            wear REAL,
            rpm REAL,
            load_pct REAL,
            prediction INTEGER,
            probability REAL,
            status TEXT
        )
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_telemetry_ts ON telemetry(ts DESC)"
    )
    conn.commit()
    conn.close()


def load_artifacts() -> None:
    global model, scaler
    if not MODEL_PATH.exists() or not SCALER_PATH.exists():
        raise FileNotFoundError(
            "model.pkl / scaler.pkl missing. Run: python train_model.py"
        )
    model = joblib.load(MODEL_PATH)
    scaler = joblib.load(SCALER_PATH)


def infer(row: dict[str, Any]) -> tuple[int, float, str]:
    features = np.array(
        [[float(row[k] if k != "load" else row["load"]) for k in FEATURE_COLS]],
        dtype=float,
    )
    scaled = scaler.transform(features)
    pred = int(model.predict(scaled)[0])
    proba = model.predict_proba(scaled)[0]
    confidence = float(proba[pred])
    return pred, confidence, STATUS_MAP[pred]


def persist(record: dict[str, Any]) -> None:
    conn = db()
    conn.execute(
        """
        INSERT INTO telemetry (
            ts, machine_id, vibration, temperature, wear, rpm, load_pct,
            prediction, probability, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (
            record["ts"],
            record["machine_id"],
            record["vibration"],
            record["temperature"],
            record["wear"],
            record["rpm"],
            record["load"],
            record["prediction"],
            record["probability"],
            record["status"],
        ),
    )
    conn.commit()
    conn.close()


def fetch_history(limit: int = 80) -> list[dict[str, Any]]:
    conn = db()
    rows = conn.execute(
        """
        SELECT ts, machine_id, vibration, temperature, wear, rpm, load_pct AS load,
               prediction, probability, status
        FROM telemetry
        ORDER BY id DESC
        LIMIT ?
        """,
        (limit,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in reversed(rows)]


def fetch_latest_by_machine() -> dict[str, dict[str, Any]]:
    conn = db()
    rows = conn.execute(
        """
        SELECT t.ts, t.machine_id, t.vibration, t.temperature, t.wear, t.rpm,
               t.load_pct AS load, t.prediction, t.probability, t.status
        FROM telemetry t
        INNER JOIN (
            SELECT machine_id, MAX(id) AS max_id FROM telemetry GROUP BY machine_id
        ) m ON t.id = m.max_id
        """
    ).fetchall()
    conn.close()
    out: dict[str, dict[str, Any]] = {}
    for r in rows:
        item = dict(r)
        meta = MACHINE_META.get(item["machine_id"], {})
        item["role"] = meta.get("role", "Station")
        item["station"] = meta.get("station", "LINE")
        out[item["machine_id"]] = item
    return out


def build_alert(record: dict[str, Any]) -> dict[str, Any] | None:
    status = record["status"]
    mid = record["machine_id"]
    if status == "CRITICAL":
        return {
            "level": "critical",
            "message": (
                f"DOWNTIME RISK — {mid} CRITICAL  |  vib {record['vibration']:.2f} mm/s  "
                f"temp {record['temperature']:.1f}°C  wear {record['wear']:.1f}%"
            ),
        }
    if status == "WARNING":
        return {
            "level": "warning",
            "message": (
                f"LINE DEGRADED — {mid} WARNING  |  vib {record['vibration']:.2f} mm/s  "
                f"temp {record['temperature']:.1f}°C  wear {record['wear']:.1f}%"
            ),
        }
    return None


def line_health(latest: dict[str, dict[str, Any]]) -> str:
    if any(m.get("status") == "CRITICAL" for m in latest.values()):
        return "CRITICAL"
    if any(m.get("status") == "WARNING" for m in latest.values()):
        return "WARNING"
    return "NOMINAL"


async def handle_telemetry(raw: dict[str, Any]) -> None:
    machine_id = str(raw.get("machine_id", "UNKNOWN"))
    record = {
        "machine_id": machine_id,
        "role": raw.get("role") or MACHINE_META.get(machine_id, {}).get("role", "Station"),
        "station": MACHINE_META.get(machine_id, {}).get("station", "LINE"),
        "ts": raw.get("ts") or datetime.now(timezone.utc).isoformat(),
        "vibration": float(raw["vibration"]),
        "temperature": float(raw["temperature"]),
        "wear": float(raw["wear"]),
        "rpm": float(raw["rpm"]),
        "load": float(raw["load"]),
    }
    pred, proba, status = infer(record)
    record["prediction"] = pred
    record["probability"] = round(proba, 4)
    record["status"] = status

    persist(record)
    hub.latest[machine_id] = record
    latest = dict(hub.latest)
    await hub.broadcast(
        {
            "type": "telemetry",
            "record": record,
            "machines": latest,
            "line_health": line_health(latest),
            "alert": build_alert(record),
        }
    )


def start_mqtt(loop: asyncio.AbstractEventLoop) -> mqtt.Client:
    client_id = f"spl-api-{uuid.uuid4().hex[:10]}"
    client = mqtt.Client(
        mqtt.CallbackAPIVersion.VERSION2,
        client_id=client_id,
        protocol=mqtt.MQTTv311,
    )

    def on_connect(c, _u, _f, reason_code, _p):
        print(f"[MQTT] subscribed rc={reason_code} topic={MQTT_TOPIC}")
        c.subscribe(MQTT_TOPIC, qos=0)

    def on_message(_c, _u, msg):
        try:
            payload = json.loads(msg.payload.decode("utf-8"))
        except Exception as exc:
            print(f"[MQTT] bad payload: {exc}")
            return
        asyncio.run_coroutine_threadsafe(handle_telemetry(payload), loop)

    def on_disconnect(_c, _u, _d, reason_code, _p):
        print(f"[MQTT] disconnected rc={reason_code}")

    client.on_connect = on_connect
    client.on_message = on_message
    client.on_disconnect = on_disconnect
    client.reconnect_delay_set(min_delay=1, max_delay=20)
    client.connect_async(BROKER_HOST, BROKER_PORT, keepalive=60)
    client.loop_start()
    print(f"[MQTT] connecting {BROKER_HOST}:{BROKER_PORT} as {client_id}")
    return client


@asynccontextmanager
async def lifespan(_app: FastAPI):
    global mqtt_client, event_loop
    init_db()
    load_artifacts()
    event_loop = asyncio.get_running_loop()
    hub.latest = fetch_latest_by_machine()
    mqtt_client = start_mqtt(event_loop)
    yield
    if mqtt_client is not None:
        mqtt_client.loop_stop()
        mqtt_client.disconnect()


app = FastAPI(title="Smart Production Line Downtime Prediction", lifespan=lifespan)
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.get("/")
async def index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/api/history")
async def api_history(limit: int = 80) -> dict[str, Any]:
    history = fetch_history(limit)
    latest = fetch_latest_by_machine()
    return {
        "history": history,
        "machines": latest,
        "line_health": line_health(latest),
    }


@app.websocket("/ws")
async def ws_telemetry(ws: WebSocket) -> None:
    await hub.connect(ws)
    snapshot = {
        "type": "snapshot",
        "history": fetch_history(80),
        "machines": hub.latest or fetch_latest_by_machine(),
        "line_health": line_health(hub.latest),
        "alert": None,
    }
    await ws.send_text(json.dumps(snapshot))
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        await hub.disconnect(ws)
    except Exception:
        await hub.disconnect(ws)
